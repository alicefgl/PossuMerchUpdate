
using System.ComponentModel.DataAnnotations;
namespace PossuMerch.Data;

public class Utente
{
    [Key]
    public string? Email { get; set; } required
    public string? Nome { get; set; } required
    public string? Cognome { get; set; } required
    public DateTime DataDiNascita { get; set; } required
    public bool NewsLetter { get; set; }

}