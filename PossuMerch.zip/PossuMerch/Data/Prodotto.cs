using System.ComponentModel.DataAnnotations;
namespace PossuMerch.Data;

public class Prodotto
{
    [Key]
    public string? _NomeP { get; set; }
    public int? quantita { get; set; }
    public int? n_prodotti { get; set; }
    public Tipo _tipoP { get; set; }
    
    public enum Tipo{
        guitar,
        bass,
        keyboard,
        drums
    }
}